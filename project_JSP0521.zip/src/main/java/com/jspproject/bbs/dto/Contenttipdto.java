package com.jspproject.bbs.dto;

public class Contenttipdto {

}
