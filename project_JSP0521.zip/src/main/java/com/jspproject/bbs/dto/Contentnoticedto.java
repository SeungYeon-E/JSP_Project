package com.jspproject.bbs.dto;

public class Contentnoticedto {

}
