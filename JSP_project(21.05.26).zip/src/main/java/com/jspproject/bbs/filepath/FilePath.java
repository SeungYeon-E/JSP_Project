package com.jspproject.bbs.filepath;

//사용하는 파일 경로들을 모아둔 클래스입니다.
//아마 실 구현시에 이러한 클래스를 공통으로 사용하는게 편하니 이런식의 사용에 익숙해지시면 좋습니다.
public class FilePath {
	public String jsp_project_filepath = "/save";
}
