package com.jspproject.bbs.dao;

public class Contenttipdao {

}
